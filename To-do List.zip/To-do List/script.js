document.getElementById('add-task-button').addEventListener('click', function() {
    const taskInput = document.getElementById('task-input');
    const taskText = taskInput.value.trim();

    if (taskText !== '') {
        const taskList = document.getElementById('task-list');

        // Create a new list item for the task
        const taskItem = document.createElement('li');
        taskItem.className = 'task-item';

        // Create a span to hold the task text
        const taskContent = document.createElement('span');
        taskContent.textContent = taskText;
        taskItem.appendChild(taskContent);

        // Create a button to delete the task
        const deleteButton = document.createElement('button');
        deleteButton.textContent = 'Delete';
        deleteButton.addEventListener('click', function() {
            taskList.removeChild(taskItem);
        });

        taskItem.appendChild(deleteButton);

        // Toggle completion on click
        taskContent.addEventListener('click', function() {
            taskItem.classList.toggle('completed');
        });

        // Add the new task to the list
        taskList.appendChild(taskItem);

        // Clear the input field
        taskInput.value = '';
    }
});
